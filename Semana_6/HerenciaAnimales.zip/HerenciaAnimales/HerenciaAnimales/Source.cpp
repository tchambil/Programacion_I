#include "MyForm.h"

using namespace HerenciaAnimales;
[STAThreadAttribute]
int main() {

	MyForm mf;
	mf.ShowDialog();
	return 0;

}