#pragma once
#ifndef HERENCIAANIMAL_TIPOS_H
#define HERENCIAANIMAL_TIPOS_H
#include <iostream>
using namespace std;
#include <iomanip>
typedef int TipoEntero;
typedef double TipoDecimal;
typedef char TipoCaracter;
typedef string TipoString;
#endif //HERENCIAANIMAL_TIPOS_H